# Maqsood Fareed — Portfolio (Static Build for Hostinger)

This folder contains a production-ready static build of the portfolio site.
No server, no database, no Node — pure HTML / CSS / JS.

## Deploy to Hostinger

1. Log in to **hPanel → File Manager**.
2. Open the `public_html` folder of the domain you want to deploy to.
3. (Optional) Delete the default `default.php` / `index.html` that Hostinger ships.
4. Upload **every file inside this folder** (including the hidden `.htaccess`) into `public_html`.
   - In Hostinger File Manager, enable "Show hidden files" so `.htaccess` is visible.
   - Or upload `maqsood-portfolio-static.zip` and use the "Extract" action.
5. Visit your domain — the site is live.

## What's included

- `index.html` — entry shell
- `static/js/*.js` — hashed JavaScript bundles
- `static/css/*.css` — hashed CSS bundles
- `static/media/*` — fonts & images bundled by webpack
- `.htaccess` — Apache config for HTTPS redirect, SPA routing fallback,
  gzip compression, long-term caching of hashed assets, and security headers.
- Favicon + manifest assets at the root.

## Contact form behaviour

In this static build the contact form opens the visitor's email client (`mailto:`)
pre-filled with their message addressed to `maqsoodfareed426@gmail.com`.

If you later want server-side handling (store submissions, send notifications),
two zero-server options that work on Hostinger shared hosting:

- **Formspree** — replace the form `action` with your Formspree endpoint.
- **Web3Forms / Getform** — same pattern.

Or deploy the bundled FastAPI backend on a separate host (Railway / Render /
Fly.io) and rebuild with `REACT_APP_BACKEND_URL=https://your-api`.

## Local preview before uploading

```bash
npx serve -s . -l 5000
# then open http://localhost:5000
```
